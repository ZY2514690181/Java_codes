package PracticeStudent;

public class StudentApp {

}
