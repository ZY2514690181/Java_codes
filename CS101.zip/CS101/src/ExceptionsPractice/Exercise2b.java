package ExceptionsPractice;

public class Exercise2b {

	public static void main(String[] args) {
		

	}

}
