package ExceptionsPractice;

public class Exercise2a {

	public static void main(String[] args) {
		
		Student somebody = new Student();
		System.out.println("Name:"+somebody.getName());
		System.out.println("Age:"+somebody.getAge());

	}

}
