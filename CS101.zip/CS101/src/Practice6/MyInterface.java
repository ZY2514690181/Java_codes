package Practice6;

public interface MyInterface {
	
	public void method1();
	public void method2();

}
