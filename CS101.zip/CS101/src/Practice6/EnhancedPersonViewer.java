package Practice6;

public class EnhancedPersonViewer {

}
