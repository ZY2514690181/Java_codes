package Practice6;

public interface Person {
	
	public String GetDescription();
	
	public String GetEmail();
	
	public String GetName();

}
