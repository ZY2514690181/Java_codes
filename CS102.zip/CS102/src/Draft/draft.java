package Draft;

public class draft {
	public static void main(String[] args) {
		double num = 0;
		num = num + 8.5+15.07+135.05;
	}

}
